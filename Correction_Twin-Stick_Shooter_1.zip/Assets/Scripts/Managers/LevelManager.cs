﻿using UnityEngine;
using UnityEngine.SceneManagement;

namespace Shooter
{
    public class LevelManager : MonoBehaviour
    {
        #region Show in inspector

        [SerializeField] private IntVariable _playerHpData = default;

        [SerializeField] private IntVariable _enemyCountData = default;

        [SerializeField] private string _nextSceneName = default;

        [SerializeField] private UIManager _uiManager = default;

        #endregion


        #region Init

        private void Awake()
        {
            Time.timeScale = 1;
        }

        #endregion


        #region Update

        // Dans Update, on va tester les conditions de victoire et de défaite
        private void Update()
        {
            // Condition de victoire : le nombre d'ennemis tombe à 0
            if (_enemyCountData._value <= 0)
            {
                Win();
            }

            // Condition de défaite : les points de vie du joueur tombent à 0
            if (_playerHpData._value <= 0)
            {
                Lose();
            }
        }

        #endregion


        #region Private methods

        // On gagne : on affiche l'UI de victoire et on met le jeu en pause
        private void Win()
        {
            _uiManager.ShowWinScreen();
            Time.timeScale = 0;
        }

        // On perd : on affiche l'UI de défaite et on met le jeu en pause
        private void Lose()
        {
            _uiManager.ShowLoseScreen();
            Time.timeScale = 0;
        }

        // Méthode appelée par l'UI Manager : redémarre le niveau actuel
        public void RestartLevel()
        {
            int currentIndex = SceneManager.GetActiveScene().buildIndex;
            SceneManager.LoadScene(currentIndex);
        }

        // Méthode appelée par l'UI Manager : passe au niveau suivant
        public void NextLevel()
        {
            SceneManager.LoadScene(_nextSceneName);
        }

        // Méthode appelée par l'UI Manager : retourne au menu principal
        public void MainMenu()
        {
            SceneManager.LoadScene(0);
        }

        #endregion
    }
}