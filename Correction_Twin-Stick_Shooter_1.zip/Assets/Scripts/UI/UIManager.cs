﻿using UnityEngine;
using TMPro;

namespace Shooter
{
    public class UIManager : MonoBehaviour
    {
        #region Show in inspector

        [Header("Player HP")]
        [SerializeField] private IntVariable _playerCurrentHpData = default;
        [SerializeField] private TMP_Text _hpValueText = default;

        [Header("Win/Lose screens")]
        [SerializeField] private Canvas _winCanvas = default;
        [SerializeField] private Canvas _loseCanvas = default;

        #endregion


        #region Update

        private void Update()
        {
            _hpValueText.text = _playerCurrentHpData._value.ToString();
        }

        public void ShowWinScreen()
        {
            _winCanvas.gameObject.SetActive(true);
        }

        public void ShowLoseScreen()
        {
            _loseCanvas.gameObject.SetActive(true);
        }

        #endregion
    }
}