﻿using UnityEngine;

namespace Shooter
{
    public class BulletCollisions : MonoBehaviour
    {
        private void OnTriggerEnter(Collider collider)
        {
            // On veut détruire la balle dès qu'elle détecte n'importe quel autre collider
            Destroy(gameObject);

            // La balle détruit un ennemi dès qu'elle le touche. On va tester si le tag du collider 
            // détecté est celui d'un ennemi
            if (collider.CompareTag("Enemy"))
            {
                Destroy(collider.gameObject);
            }
            // Si la balle touche l'avant de l'ennemi, alors on détruit le parent (c'est-à-dire l'ennemi en entier).
            else if (collider.CompareTag("EnemyFront"))
            {
                Destroy(collider.transform.parent.gameObject);
            }
            // Si la balle touche le bouclier d'un ennemi, alors on ne le détruit pas, et en plus on peut
            // afficher un VFX ou jouer un SFX particulier.
            else if (collider.CompareTag("EnemyShield"))
            {
                // Dans ce cas on ne fait rien (on pourrait donc ne pas faire de if tout court)
                // On peut jouer par exemple un VFX et un SFX
            }
        }
    }
}