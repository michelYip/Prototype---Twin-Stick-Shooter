﻿using UnityEngine;

namespace Shooter
{
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerBullet : MonoBehaviour
    {
        #region Init

        // Awake : initialisation des références vers les différents composants dont on aura besoin
        private void Awake()
        {
            _transform = GetComponent<Transform>(); // ou transform tout simplement
            _rigidbody = GetComponent<Rigidbody>();
        }

        #endregion


        #region Update

        private void FixedUpdate()
        {
            // On va utiliser la méthode Rigidbody.MovePosition parce que le Rigidbody de la balle est kinematic.
            // On ne peut pas utiliser ni Rigidbody.velocity ni Rigidbody.AddForce

            // Calcul de la nouvelle position de la balle :

            // 1) La direction : l'axe forward de la balle (l'axe z local)
            Vector3 direction = _transform.forward;

            // 2) Le vecteur vitesse : la direction * la vitesse en m/s
            Vector3 velocity = direction * _speed;

            // 3) La translation : le vecteur vitesse * le pas de temps 
            Vector3 translation = velocity * Time.fixedDeltaTime;

            // 4) La nouvelle position : la position actuelle + la translation
            Vector3 newPosition = _transform.position + translation;

            #region Optionnel : balles à très grandes vitesses

            // On teste si durant cette translation, on rencontre un obstacle (on verra les raycast en 2e semaine)
            if (Physics.Raycast(_transform.position, direction, out RaycastHit hit, _speed * Time.fixedDeltaTime))
            {
                // Si on rencontre un obstacle, alors on s'arrête au point d'impact
                newPosition = hit.point;
            }

            #endregion

            // Enfin on déplace le rigidbody à la nouvelle position
            _rigidbody.MovePosition(newPosition);

        }

        #endregion


        #region Public

        // Change la vitesse de la balle. Cette méthode est appelée par PlayerShoot au moment de la création de la balle.
        public void Shoot(float speed)
        {
            _speed = speed;
        }

        #endregion


        #region Private

        private Transform _transform;
        private Rigidbody _rigidbody;

        // La vitesse interne de la balle en m/s
        private float _speed;

        #endregion
    }
}