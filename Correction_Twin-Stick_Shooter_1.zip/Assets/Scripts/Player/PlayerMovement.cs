﻿using UnityEngine;

namespace Shooter
{
    public class PlayerMovement : MonoBehaviour
    {
        #region Show in inspector

        [Tooltip("Le S.O. représentant le Transform du joueur")]
        [SerializeField] private TransformVariable _playerTransformData = default;

        [Header("Paramètres")]

        [Tooltip("La vitesse de déplacement, en m/s")]
        [SerializeField] private float _speed = default;

        #endregion


        #region Init

        // Initialisation phase 1 : Awake est appelée en premier, à la création du GameObject, c'est-à-dire :
        //          * Soit au chargement d'une scène (au démarrage du jeu, ou bien lorsqu'on charge une nouvelle scène)
        //          * Soit à la création du GameObject (par new GameObject() ou avec la fonction Instantiate).
        //      => Je récupère les références vers les autres composants / GameObjects
        //      => J'intialise certaines valeurs simples
        private void Awake()
        {
            _rigidbody = GetComponent<Rigidbody>();

            // Pas obligé de le faire, ces valeurs sont déjà Vector3.zero par défaut
            _movementDirection = Vector3.zero;
            _rotationDirection = Vector3.zero;

            // On utilise un S.O. pour stocker le Transform du joueur. On pourra donc utiliser ce S.O. dans les différents prefabs Enemy, 
            // puisque les S.O. sont, comme les prefabs, des assets en dehors de la scène
            _playerTransformData.Value = transform;
        }

        // Initialisation phase 2 : Start est appelée après tous les Awake de tous les composants de tous les GameObjects.
        //      => J'utilise d'autres composants / GameObjects pour m'initialiser
        private void Start()
        {
            // Ici on n'a rien à faire en Start, donc on peut omettre d'écrire cette méthode pour économiser du calcul.
        }

        #endregion


        #region Update

        // Update est appelée à chaque frame (toutes les 16.66ms à 60 fps)
        // Tous les inputs du joueur doivent être testés dans Update.
        private void Update()
        {
            // Récupère le vecteur de direction du mouvement à partir des inputs
            MovementInput();

            // Récupère le vecteur de direction de la rotation à partir des inputs
            RotationInput();
        }

        // LateUpdate est appelée à chaque frame, après toutes les Updates de tous les composants de tous les GameObjects
        private void LateUpdate()
        {
            // On n'a rien à faire en LateUpdate, donc on peut omettre d'écrire cette méthode pour économiser du calcul.
        }

        // FixedUpdate est appelée à chaque pas de calcul du moteur physique (toutes les 20ms par défaut)
        private void FixedUpdate()
        {
            // Applique le mouvement au Rigidbody
            Move();

            // On ne veut pas appliquer de rotation si on n'a pas d'input de rotation. On teste donc si ce vecteur est
            // égal au vecteur 0. Dans ce cas, on sort directement de la méthode FixedUpdate.
            if (_rotationDirection == Vector3.zero)
            {
                return;
            }

            // Applique la rotation au Rigidbody (si on arrive ici, on est sûr qu'on a un input d'orientation)
            Turn();
        }

        #endregion


        #region Input

        // Récupère le vecteur de direction du mouvement à partir des inputs
        private void MovementInput()
        {
            // On récupère les inputs du joueur sur les "Horizontal" et "Vertical" définis dans l'InputManager de Unity.
            float horizontal = Input.GetAxisRaw("Horizontal");
            float vertical = Input.GetAxisRaw("Vertical");

            // On crée un Vector3 à partir de ces valeurs pour créer un vecteur de direction. 
            // C'est la direction dans laquelle on veut déplacer le personnage.
            _movementDirection = new Vector3(horizontal, 0, vertical);

            // On calcule de la quantité d'input. La quantité de mouvement représente l'intensité avec laquelle on a appuyé sur la touche.
            // Ce float permet de moduler le mouvement, et d'aller moins vite si on appuie moins fort sur le joystick.
            _inputQuantity = _movementDirection.magnitude;

            // Au gamepad, ce sera un float toujours inférieur à 1, car le joystick se déplace dans un cercle.
            // Au clavier, ce sera un float qui peut valoir 0, 1 ou 2^-2 si on appuie sur deux directions en même temps.
            // On ne veut pas que la quantité de mouvement soit supérieure à 1 pour ne pas avoir une vitesse supérieure quand
            // on se déplace en diagonale.
            // On va donc clamper à 1 pour rester dans le même cercle qu'au joystick.
            _inputQuantity = Mathf.Clamp01(_inputQuantity);

            // Equivalent à :
            //_inputQuantity = Mathf.Clamp(_inputQuantity, 0, 1);

            // Equivalent à :
            //_inputQuantity = Mathf.Max(Mathf.Min(_inputQuantity, 1), 0);

            // Equivalent à :
            //if (_inputQuantity < 0)
            //{
            //    _inputQuantity = 0;
            //} 
            //else if (_inputQuantity > 1)
            //{
            //    _inputQuantity = 1;
            //}

            // Enfin, on peut maintenant normaliser le vecteur pour obtenir un vecteur de longueur 1 (donc une direction), encore
            // une fois pour ne pas fausser la vitesse.
            _movementDirection.Normalize();
        }

        // Récupère le vecteur de direction de la rotation à partir des inputs
        private void RotationInput()
        {
            // On récupère les inputs du joueur sur les "Orientation_Horizontal" et "Orientation_Vertical" définis dans l'InputManager de Unity.
            float rightHorizontal = Input.GetAxisRaw("Orientation_Horizontal");
            float rightVertical = Input.GetAxisRaw("Orientation_Vertical");

            // On crée un Vector3 à partir de ces valeurs pour créer un vecteur de direction. 
            // C'est la direction dans laquelle on veut tourner le personnage.
            _rotationDirection = new Vector3(rightHorizontal, 0, rightVertical);
            // On normalise le vecteur pour obtenir un vecteur de direction/
            _rotationDirection.Normalize();
            // NB, il n'est pas vraiment nécessaire dans notre cas de normaliser le vecteur, car on ne va pas le multiplier.
            // Une longueur différente de 1 ne risque donc pas de fausser les calculs.
        }

        #endregion


        #region Movement

        // Applique le mouvement au Rigidbody
        private void Move()
        {
            // On calcule le vecteur vitesse à partir de la direction et de la vitesse.
            // C'est le déplacement que va effectuer le Rigidbody en m/s
            Vector3 velocity = _movementDirection * _speed * _inputQuantity;

            // On applique ce vecteur vitesse au Rigidbody en modifiant directement son propre vecteur vitesse.
            _rigidbody.velocity = velocity;

            // C'est le moteur physique de Unity qui va calculer ensuite les positions du Rigidbody à chaque frame
            // en fonction de ce vecteur vitesse.
        }

        // Applique la rotation au Rigidbody
        private void Turn()
        {
            // On calcule la rotation vers laquelle pointe la direction de rotation grâce à un Quaternion.
            Quaternion lookRotation = Quaternion.LookRotation(_rotationDirection);

            // Si le vecteur qu'on donne à la fonction Quaternion.LookRotation est (0, 0, 0) (donc de longueur 0), alors
            // Unity affiche un message et retourne la valeur Quaternion.identity.

            // On applique cette rotation directement au Rigidbody.
            _rigidbody.MoveRotation(lookRotation);
        }

        #endregion


        #region Private

        private Rigidbody _rigidbody;
        private Vector3 _movementDirection;
        private Vector3 _rotationDirection;
        private float _inputQuantity;

        #endregion
    }
}