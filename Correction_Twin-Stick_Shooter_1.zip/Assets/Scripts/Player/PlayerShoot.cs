﻿using UnityEngine;

namespace Shooter
{
    public class PlayerShoot : MonoBehaviour
    {
        #region Show in inspector

        [Tooltip("Quel est le modèle de la balle ?")]
        [SerializeField] private PlayerBullet _bulletPrefab = default;

        [Tooltip("Où fait-on apparaître les balles ?")]
        [SerializeField] private Transform _cannon = default;

        [Tooltip("Où stocke-t-on les balles ? Attention, ce ne doit pas être dans un GameObject qui peut bouger.")]
        [SerializeField] private Transform _bulletContainer = default;

        [Header("Paramètres du tir")]

        [Tooltip("La vitesse de la balle en m/s")]
        [SerializeField] private float _bulletSpeed = default;

        [Tooltip("Le délai en secondes entre deux tirs")]
        [SerializeField] private float _delayBetweenShots = default;

        [Tooltip("Le délai en secondes avant destruction de la balle")]
        [SerializeField] private float _bulletTimeToLive = default;

        #endregion


        #region Update

        private void Update()
        {
            // Est-ce qu'on appuie sur le bouton pour tirer ?
            // On utilise un axe pour pouvoir tester à la fois la gâchette du gamepad et une touche du clavier
            // On utilise une petite valeur proche de 0 comme seuil
            if (Input.GetAxisRaw("Fire") > 0.1f)
            {
                // Est-ce qu'on a dépassé la date à laquelle on peut tirer ?
                if (Time.time > _nextShotTime)
                {
                    // Si oui, on tire...
                    FireBullet();
                    // ... et on calcule la prochaine date à partir de la date actuelle
                    _nextShotTime = Time.time + _delayBetweenShots;
                }
            }

            // NB. on peut également écrire ces deux conditions en un seul if
            // if (Input.GetAxisRaw("Fire") > 0.1f && Time.time > _nextShotTime)
        }

        // Crée une balle et lui donne une vitesse initiale
        private void FireBullet()
        {
            // Instancie un nouveau GameObject à partir du prefab, positionné sur le canon, et avec la rotation du canon.
            PlayerBullet newBullet = Instantiate(_bulletPrefab, _cannon.position, _cannon.rotation, _bulletContainer);
            // Appelle la méthode public PlayerBullet.Shoot pour donner une vitesse à cette balle.
            newBullet.Shoot(_bulletSpeed);
            // Planifie la destruction de la balle (si jamais elle ne rencontre aucun obstacle avant).
            Destroy(newBullet.gameObject, _bulletTimeToLive);
        }

        #endregion


        #region Private

        private float _nextShotTime;

        #endregion
    }
}