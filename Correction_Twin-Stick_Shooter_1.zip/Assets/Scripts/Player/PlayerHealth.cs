﻿using UnityEngine;

namespace Shooter
{
    public class PlayerHealth : MonoBehaviour
    {
        #region Show in inspector

        [Tooltip("Le S.O. représentant les points de vie courants du joueur")]
        [SerializeField] private IntVariable _playerHpData = default;

        [Tooltip("Le S.O. représentant les points de vie max du joueur")]
        [SerializeField] private IntVariable _playerMaxHpData = default;

        #endregion


        #region Init

        // À l'initialisation, on met les points de vie courant du joueur au maximum de ses points de vie
        private void Awake()
        {
            // Attention à bien utiliser .Value !
            _playerHpData._value = _playerMaxHpData._value;
        }

        #endregion
    }
}