﻿using UnityEngine;

namespace Shooter
{
    [CreateAssetMenu(menuName = "Variables/Int")]
    public class IntVariable : ScriptableObject
    {
        public int _value;
    }
}