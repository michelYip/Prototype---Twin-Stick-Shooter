﻿using UnityEngine;

namespace Shooter
{
    [CreateAssetMenu(menuName = "Variables/Transform")]
    public class TransformVariable : ScriptableObject
    {
        public Transform Value;
    }
}