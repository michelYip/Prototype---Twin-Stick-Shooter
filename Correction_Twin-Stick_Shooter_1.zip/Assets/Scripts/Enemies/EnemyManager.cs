﻿using UnityEngine;

namespace Shooter
{
    public class EnemyManager : MonoBehaviour
    {
        #region Show in inspector

        [Tooltip("Le S.O. représentant le nombre total d'ennemis")]
        [SerializeField] private IntVariable _enemyCountData = default;

        #endregion


        #region Init

        // On initialise le S.O. représentant le nombre total d'ennemis en comptant dans la scène 
        // le nombre de GameObjects portant le tag Enemy
        private void Awake()
        {
            int count = GameObject.FindGameObjectsWithTag("Enemy").Length;
            _enemyCountData._value = count;
        }

        #endregion
    }
}