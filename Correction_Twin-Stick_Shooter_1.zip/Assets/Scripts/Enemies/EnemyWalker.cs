﻿using UnityEngine;

namespace Shooter
{
    [RequireComponent(typeof(Rigidbody))]
    public class EnemyWalker : MonoBehaviour
    {
        #region Show in inspector

        [Tooltip("Le S.O. représentant le Transform du joueur")]
        [SerializeField] private TransformVariable _playerTransformData = default;

        [Tooltip("La vitesse de déplacement de l'ennemi, en m/s")]
        [SerializeField] private float _movementSpeed = default;

        [Tooltip("La vitesse de rotation de l'ennemi, en °/s")]
        [SerializeField] private float _rotationSpeed = default;

        #endregion


        #region Init

        private void Awake()
        {
            _transform = GetComponent<Transform>();
            _rigidbody = GetComponent<Rigidbody>();
        }

        #endregion


        #region Update

        private void FixedUpdate()
        {
            // On teste d'abord s'il y a une valeur Transform dans la variable
            if (_playerTransformData.Value == null)
            {
                return;
            }

            // Fait tourner l'ennemi vers le joueur
            TurnTowardsPlayer();
            // Fait avancer l'ennemi tout droit (donc progressivement vers le joueur).
            MoveForward();
        }

        #endregion


        #region Private methods

        // Fait tourner l'ennemi vers le joueur
        private void TurnTowardsPlayer()
        {
            // On calcule le vecteur qui relie la position de l'ennemi à la position du joueur.
            // En calcul vectoriel, il s'agit de (position d'arrivée - position de départ).
            // On normalise le vecteur résultat pour obtenir une direction.
            Vector3 directionToPlayer = (_playerTransformData.Value.position - _transform.position).normalized;

            // On calcule la rotation vers cette direction (comme pour la rotation du joueur).
            Quaternion rotationToPlayer = Quaternion.LookRotation(directionToPlayer);

            // On ne veut pas que l'ennemi tourne d'un coup vers le joueur. On utilise un calcul avec
            // la méthode Quaterion.RotateTowards pour obtenir une rotation intermédiaire en fonction d'un 
            // angle max donné en 3e paramètre.
            // En multipliant cet angle par Time.fixedDeltaTime, on peut paramétrer l'angle comme des degrés par seconde dans l'inspecteur
            Quaternion rotation = Quaternion.RotateTowards(_transform.rotation, rotationToPlayer, _rotationSpeed * Time.fixedDeltaTime);

            // Enfin on applique la rotation au Rigidbody
            _rigidbody.MoveRotation(rotation);
        }

        // Fait avancer l'ennemi tout droit
        private void MoveForward()
        {
            // Tout comme le déplacement du joueur, on calcule un vecteur vitesse.
            // Ici la direction du mouvement est la direction forward de l'ennemi.
            Vector3 velocity = _transform.forward * _movementSpeed;
            _rigidbody.velocity = velocity;
        }

        #endregion


        #region Private

        private Transform _transform;
        private Rigidbody _rigidbody;

        #endregion
    }
}