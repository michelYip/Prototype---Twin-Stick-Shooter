﻿using UnityEngine;

namespace Shooter
{
    public class EnemyCollisions : MonoBehaviour
    {
        #region Show in inspector

        [Tooltip("Les dégâts que fait cet ennemi")]
        [SerializeField] private int _damage = default;

        [Tooltip("Le S.O. représentant les points de vie du joueur")]
        [SerializeField] private IntVariable _playerHpData = default;

        [Tooltip("Le S.O. représentant le nombre total d'ennemis")]
        [SerializeField] private IntVariable _enemyCountData = default;

        #endregion


        #region Unity lifecycle

        // OnDestroy est appelée dès que le GameObject est détruit.
        // Quand l'ennemi est détruit par la balle, on veut décrémenter le compte total d'ennemis.
        private void OnDestroy()
        {
            _enemyCountData._value--;
            // Equivalent à :
            //_enemyCountData._value -= 1;
            // Equivalent à :
            //_enemyCountData._value = _enemyCountData._value - 1;
        }

        #endregion


        #region Collisions

        // Collision avec le joueur : on décrémente les points de vie courants du joueur
        private void OnCollisionEnter(Collision collision)
        {
            // Teste si le GameObject avec lequel on est entré en collision porte le tag Player
            if (collision.gameObject.CompareTag("Player"))
            {
                _playerHpData._value -= _damage;
            }
        }

        #endregion
    }
}